import StoreFront from "./page.client";

export default async function Home() {
  return <StoreFront />;
}
